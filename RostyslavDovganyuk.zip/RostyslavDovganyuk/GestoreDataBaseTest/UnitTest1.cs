using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Utili;
using GestoreDataBase;
using System.Collections.Generic;
using System.Linq;

namespace GestoreDataBaseTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestKeyOnDictionary()
        {

            IGestoreDB db = new GestoreDB();
            
            var prenotazione = PrenotazioneTest();

            db.SavePrenotazione(prenotazione);

            var dict = db.DictionaryPrenotazioni(prenotazione.PeriodoPrenotazione);

            Assert.AreEqual(dict.ContainsKey(prenotazione.DataPrenotazione),true);
        }

        [TestMethod]
        public void TestValueOnDictionary()
        {
            IGestoreDB db = new GestoreDB();
            
            var prenotazione = PrenotazioneTest();

            db.SavePrenotazione(prenotazione);

            var dict = db.DictionaryPrenotazioni(prenotazione.PeriodoPrenotazione);

            //prelevo i valori dal Dizionario
            var key = prenotazione.DataPrenotazione;
            var list = dict.TryGetValue(key, out List<Prenotazione> value);

            bool isContained = false;

            value.ForEach(v => {
                    if(v.CodicePrenotazione.Equals(prenotazione.Prenotazione.CodicePrenotazione))
                    {
                        isContained = true;
                    }
                });

            Assert.AreEqual(isContained,true);

        }


        private PrenotazioneEstesa PrenotazioneTest()
        {
            //creo un cliente
            var cliente1 = new Cliente()
            {
                Nome = "Mario",
                Cognome = "Draghi",
                Email = "mario.draghi@gmail.com",
                Telefono = "1200457825"
            };

            //creo il tavolo
            var tavolo1 = new Tavolo()
            {
                Id = 1,
                MaxPosti = 8
            };

            //La data della prenotazione
            DateTime data = DateTime.Today;

            string codice = RandomString(7);

            //creo la prenotazione (estesa)
            return new PrenotazioneEstesa(EnPeriodo.Periodo.PRANZO,data,codice,8,cliente1,tavolo1);

        }

        private Random random = new Random();
        //Funzione presa da internet per la generazione di codici per la prenotazione
        public string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
            .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        
        

    }


}
