namespace Utili
{
     public class Cliente
    {
        public string Nome {get; set;}
        public string Cognome {get; set;}
        public string Email {get; set;}
        public string Telefono {get; set;}

/*
        public Cliente(string nome, string cognome, string email, string telefono) 
        {
            this.nome = nome;
            this.cognome = cognome;
            this.email = email;
            this.telefono = telefono;
        }

        public string Nome
        {
            get{ return this.nome; }
        }

        public string Cognome
        {
            get { return this.cognome; }
        }

        public string Email
        {
            get { return this.email; }
        }
        
        public string Telefono
        {
            get { return this.telefono; }
        }
*/
    }
}