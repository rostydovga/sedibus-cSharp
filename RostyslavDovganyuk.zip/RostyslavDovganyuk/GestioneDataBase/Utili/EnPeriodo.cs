using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utili
{
    /// <summary>
    /// Seppur C# non preveda gli enum, preferisco tenere 
    /// gli enum in un unica classe, visto che vengono usate da diverse classi
    /// </summary>
    public class EnPeriodo
    {
       public enum Periodo { PRANZO, CENA }
    }
}