using System;
using System.Collections.Generic;
using System.Text;

namespace Utili
{
    //Estensione della Prenotazione, utile per il metodo di caricamento della prenotazione nel file
    //In quanto la PrenotazioneEstesa contiene i parametri necessari per "instradare" il salvataggio della Prenotazione
    public class PrenotazioneEstesa : Prenotazione
    {

        private DateTime dataPrenotazione;
        private Prenotazione prenotazione;
        private EnPeriodo.Periodo p;

        public PrenotazioneEstesa(EnPeriodo.Periodo periodo, DateTime data, string codicePrenotaz,int postiPrenotati, Cliente cliente, Tavolo tavolo)
        {
            this.p = periodo;
            this.dataPrenotazione = data;

            this.prenotazione = new Prenotazione();
            this.prenotazione.CodicePrenotazione = codicePrenotaz;
            this.prenotazione.Cliente = cliente;
            this.prenotazione.Tavolo = tavolo;
            this.prenotazione.NPostiPrenotati = postiPrenotati;
        }

        
        public Prenotazione Prenotazione
        {
            get { return this.prenotazione; }
        }

        public EnPeriodo.Periodo PeriodoPrenotazione
        {
            get { return this.p; }
        }

        public DateTime DataPrenotazione
        {
            get { return this.dataPrenotazione; }
        }

    }
}