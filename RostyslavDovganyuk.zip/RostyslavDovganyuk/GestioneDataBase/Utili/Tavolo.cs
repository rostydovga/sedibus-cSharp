namespace Utili
{
    public class Tavolo
    {

        public int Id {get; set;}
        public int MaxPosti {get; set;}

/*
        public Tavolo(int id, int maxPosti)
        {
            this.id = id;
            this.maxPosti = maxPosti;
        }

        public int Id
        {
            get { return this.id; }
        }

        public int MaxPosti
        {
            get { return this.maxPosti; }
        }
*/
    }
}