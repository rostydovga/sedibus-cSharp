namespace Utili
{
    //Contiene i dati base inerenti a una Nnormale Prenotazione
    public class Prenotazione
    {
        public string CodicePrenotazione { get; set; }
        public Cliente Cliente { get; set; }
        public Tavolo Tavolo { get; set; }
        public int NPostiPrenotati { get; set; }
    }
}