using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.IO;
using Utili;

namespace GestoreDataBase
{
    public class GestoreDB : IGestoreDB
    {

        readonly static string FILE_PRANZO = "pranzo.json";
        readonly static string FILE_CENA = "cena.json";

        public GestoreDB()
        {
            CheckFile();
        }

        //crea i file se non esistono
        private void CheckFile()
        {
            if (!File.Exists(FILE_PRANZO))
            {
                File.Create(FILE_PRANZO);
            }
            if (!File.Exists(FILE_CENA))
            {
                File.Create(FILE_CENA);
            }

        }
        
        private string GetPathFile(EnPeriodo.Periodo p)
        {
            return p.Equals(EnPeriodo.Periodo.PRANZO) ? FILE_PRANZO : FILE_CENA;
        }
        


        public Dictionary<DateTime,List<Prenotazione>> DictionaryPrenotazioni(EnPeriodo.Periodo periodo)
        {

            Dictionary<DateTime,List<Prenotazione>> dict = JsonConvert.DeserializeObject<Dictionary<DateTime,List<Prenotazione>>>(File.ReadAllText(GetPathFile(periodo)));

            return dict;
        }
        
        public void SavePrenotazione(PrenotazioneEstesa prenotazione)
        {
            //prendo il dizionario gia presente nel file
            var dict = DictionaryPrenotazioni(prenotazione.PeriodoPrenotazione);

            
                if(dict != null && dict.TryGetValue(prenotazione.DataPrenotazione, out List<Prenotazione> list))
                {
                    
                    list.Add(prenotazione.Prenotazione);
                }
                else
                {
                    if(dict == null)
                    {
                        dict = new Dictionary<DateTime, List<Prenotazione>>();
                    }

                    dict.Add(prenotazione.DataPrenotazione, new List<Prenotazione>{prenotazione.Prenotazione});
                }   
               
            LoadDictionaryOnFile(prenotazione.PeriodoPrenotazione, dict);
        }


        /// <summary>
        /// Carica il Dictionary nel file (<param>periodo</param>).json
        /// </summary>
        private void LoadDictionaryOnFile(EnPeriodo.Periodo periodo, Dictionary<DateTime,List<Prenotazione>> dictionary)
        {

            string jsonString = JsonConvert.SerializeObject(dictionary, Newtonsoft.Json.Formatting.Indented);

            File.WriteAllText(GetPathFile(periodo), jsonString);

            
        }


    }
}