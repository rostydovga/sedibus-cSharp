using System;
using System.Collections.Generic;
using System.Text;
using Utili;

namespace GestoreDataBase
{
    public interface IGestoreDB
    {
        /// <summary>
        /// Preleva dal file (<param>periodo</param>).json le informazioni e le incapsula in un Dictionary
        /// </summary>
        /// <returns>
        /// Dictionary di prenotazioni inerenti a un dato periodo
        /// </returns>
        Dictionary<DateTime, List<Prenotazione>>  DictionaryPrenotazioni(EnPeriodo.Periodo periodo);
        

        /// <summary>
        /// Data la <param>param</param>, di tipo PrenotazioneEstesa, il metodo spacchetta l'elemento e si occupa di 
        /// "legare" la prenotazione alla chiave, del Dictionary giusta, per poi delegare il 
        /// caricamento del dictionary nel file a una funzione apposita
        /// </summary>
        void SavePrenotazione(PrenotazioneEstesa prenotazione);


    }
}