﻿using System;
using Utili;
using GestoreDataBase;
using System.Collections.Generic;
using Newtonsoft;

namespace Rostyslav_Dovganyuk
{
    class Program
    {
        static void Main(string[] args)
        {
            //creo un cliente
            var cliente1 = new Cliente()
            {
                Nome = "Mario",
                Cognome = "Draghi",
                Email = "mario.draghi@gmail.com",
                Telefono = "1200457825"
            };

            //creo il tavolo
            var tavolo1 = new Tavolo()
            {
                Id = 1,
                MaxPosti = 8
            };

            //La data della prenotazione
            DateTime data = DateTime.Today;

            string codice = "BBCC145";

            //creo la prenotazione (estesa)
            var prenotazione = new PrenotazioneEstesa(EnPeriodo.Periodo.PRANZO,data,codice,8,cliente1,tavolo1);

            IGestoreDB db = new GestoreDB();

            
            db.SavePrenotazione(prenotazione);
            
        }
    }
}
