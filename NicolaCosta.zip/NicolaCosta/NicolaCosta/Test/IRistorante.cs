﻿using System.Collections.Generic;

namespace Test
{
    public interface IRistorante
    {
        public IDictionary<string, IList<Prenotazione>> GetPrenotazioni(Periodo p);
    }
}
