﻿namespace Test
{
    public class Tavolo
    {
        private readonly int nome;
        private readonly int maxPosti;

        public Tavolo(int nome, int maxPosti)
        {
            this.nome = nome;
            this.maxPosti = maxPosti;
        }

        public int GetNome()
        {
            return this.nome;
        }

        public int GetMaxPosti()
        {
            return this.maxPosti;
        }

    }
}