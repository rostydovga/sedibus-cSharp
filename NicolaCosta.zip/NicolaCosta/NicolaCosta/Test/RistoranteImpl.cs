﻿using System.Collections.Generic;

namespace Test
{
    public class RistoranteImpl : IRistorante
    {

        private readonly IGestoreDB gestoreDB = new GestoreDBImpl();

        public IDictionary<string, IList<Prenotazione>> GetPrenotazioni(Periodo p)
        {
            return this.gestoreDB.GetDicPrenotazioni(p);
        }
    }

}
