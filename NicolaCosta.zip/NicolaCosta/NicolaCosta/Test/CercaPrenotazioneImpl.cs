﻿using System;

namespace Test
{
    public class CercaPrenotazioneImpl : ICercaPrenotazione
    {

        private readonly IRistorante ristorante = new RistoranteImpl();
        private bool prenotazTrovata;
        private DateTime data;
        private Prenotazione prenotazione;
        private string codice;
        private string cognome;
        private Periodo periodo;

        public CercaPrenotazioneImpl()
        {
            this.prenotazTrovata = false;
        }

        public bool CercaDati()
        {
            foreach(var elem in this.ristorante.GetPrenotazioni(this.periodo))
            {
                foreach(var pren in elem.Value)
                {
                    if(pren.GetCodicePrenotazione().Equals(this.codice) && pren.GetCliente().GetCognome().Equals(this.cognome))
                    {
                        this.prenotazione = pren;
                        this.data = DateTime.Parse(elem.Key).Date;
                        this.prenotazTrovata = true;
                    }
                }
            }
            return this.prenotazTrovata;
        }

        public DateTime GetData()
        {
            return this.data.Date;
        }

        public string GetEmail()
        {
            return this.prenotazione.GetCliente().GetNome();
        }

        public string GetIdTavolo()
        {
            return this.prenotazione.GetTavolo().GetNome().ToString();
        }

        public string GetNome()
        {
            return this.prenotazione.GetCliente().GetNome();
        }

        public string GetPosti()
        {
            return this.prenotazione.GetPostiPrenotati().ToString();
        }

        public Prenotazione GetPrenotazione()
        {
            return this.prenotazione;
        }

        public string GetTelefono()
        {
            return this.prenotazione.GetCliente().GetTelefono();
        }

        public void PrendiDati(string cod, string cognome, Periodo periodo)
        {
            this.codice = cod;
            this.cognome = cognome;
            this.periodo = periodo;
        }

    }
}
