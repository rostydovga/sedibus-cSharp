using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Test
{
    [TestClass]
    public class UnitTest1
    {

        private ICercaPrenotazione cerca;

        [TestMethod]
        public void TestMethod1()
        {
            this.cerca = new CercaPrenotazioneImpl();
            this.cerca.PrendiDati("X0004", "Costa", Periodo.PRANZO);
            Assert.IsTrue(this.cerca.CercaDati());
        }

        [TestMethod]
        public void TestMethod2()
        {
            this.cerca = new CercaPrenotazioneImpl();
            this.cerca.PrendiDati("T0001", "Dovga", Periodo.PRANZO);
            Assert.IsFalse(this.cerca.CercaDati());
        }
    }
}
