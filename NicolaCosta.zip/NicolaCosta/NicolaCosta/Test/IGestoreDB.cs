﻿using System.Collections.Generic;

namespace Test
{
    public interface IGestoreDB
    {
        IDictionary<string, IList<Prenotazione>> GetDicPrenotazioni(Periodo p);
    }
}
