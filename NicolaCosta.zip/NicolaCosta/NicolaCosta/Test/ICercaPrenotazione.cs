﻿using System;

namespace Test
{
    public interface ICercaPrenotazione
    {
        void PrendiDati(String cod, String cognome, Periodo periodo);

        bool CercaDati();

        Prenotazione GetPrenotazione();

        string GetNome();

        string GetEmail();

        string GetTelefono();

        DateTime GetData();

        string GetPosti();

        string GetIdTavolo();
    }

}
