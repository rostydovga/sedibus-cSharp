﻿namespace Test
{
    public class Cliente
    {
        private readonly string nome;
        private readonly string cognome;
        private readonly string email;
        private readonly string nTelefono;

        public Cliente(string nomeCliente, string cognomeCliente, string emailCliente, string telefonoCliente)
        {
            this.nome = nomeCliente;
            this.cognome = cognomeCliente;
            this.email = emailCliente;
            this.nTelefono = telefonoCliente;
        }

        public string GetNome()
        {
            return this.nome;
        }

        public string GetCognome()
        {
            return this.cognome;
        }

        public string GetEmail()
        {
            return this.email;
        }

        public string GetTelefono()
        {
            return this.nTelefono;
        }
    }
}