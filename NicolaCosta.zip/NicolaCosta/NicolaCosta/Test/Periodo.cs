﻿namespace Test
{
    public enum Periodo
    {
        PRANZO,
        CENA
    }
}