﻿using System.Collections.Generic;

namespace Test
{
    public class GestoreDBImpl : IGestoreDB
    {
        public IDictionary<string, IList<Prenotazione>> GetDicPrenotazioni(Periodo p)
        {
            return new Dictionary<string, IList<Prenotazione>>()
            {
                { "2021-04-19", new List<Prenotazione>()
                {
                    new Prenotazione("A0001", new Cliente("Nicola", "Costa", "n.c@mail.it", "111222333"), new Tavolo(1, 4), 2),
                    new Prenotazione("X0002", new Cliente("Ilaria", "Costa", "i.c@mail.it", "999888000"), new Tavolo(6, 10), 10),
                    new Prenotazione("X0004", new Cliente("Ivano", "Costa", "ivco@mail.it", "999111111"), new Tavolo(2, 2), 2)
                } },
                { "2021-04-22", new List<Prenotazione>()
                {
                    new Prenotazione("R0043", new Cliente("Rosti", "Dovga", "r.d@mail.it", "333222777"), new Tavolo(1, 4), 3)
                } }
            };
        }
    }
}
