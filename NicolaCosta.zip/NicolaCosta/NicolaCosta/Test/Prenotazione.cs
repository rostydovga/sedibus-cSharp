﻿namespace Test
{
    public class Prenotazione
    {
        private readonly string codicePrenotazione;
        private readonly Cliente cliente;
        private readonly Tavolo tavolo;
        private readonly int nPostiPrenotati;

        public Prenotazione(string codicePrenotazione, Cliente cliente, Tavolo tavolo, int nPostiPrenotati)
        {
            this.codicePrenotazione = codicePrenotazione;
            this.cliente = cliente;
            this.tavolo = tavolo;
            this.nPostiPrenotati = nPostiPrenotati;
        }

        public string GetCodicePrenotazione()
        {
            return this.codicePrenotazione;
        }

        public Cliente GetCliente()
        {
            return this.cliente;
        }

        public Tavolo GetTavolo()
        {
            return this.tavolo;
        }

        public int GetPostiPrenotati()
        {
            return this.nPostiPrenotati;
        }

        public Prenotazione GetPrenotazione()
        {
            return new Prenotazione(this.GetCodicePrenotazione(), this.GetCliente(), this.GetTavolo(), this.GetPostiPrenotati());
        }
    }
}